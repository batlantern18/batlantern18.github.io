# Minecoins
# Created: 11/27/2021 [mm/dd/YYYY]
# Version: 2.0.0
# Made for MC Bedrock Edition 1.18
# For more info visit https://github.com/batlantern18

*UNZIP THE PACKAGE!*

EXPERIMENTAL PACK WARNING
=========================
This won't work without the "Holiday Creator Features" Experiments Toggle selected in your world.

WHAT IS IT?
===========
This is a pack for the currency of Minecoin from the Marketplace!

HOW TO CRAFT (Shapeless)
========================
4 Minecoins = 1 Minecoin Block
1 Minecoin Block = 4 Minecoins

HOW TO CRAFT MINECOINS (Shaped)
===============================
#D
G#

KEY
---
# = Gold Nugget
D = Diamond
G = Gold Ingot

*INCLUDED THE .BRPROJECT*

HOW TO IMPORT THE .BRPROJECT INTO BRIDGE
========================================
1. Go to https://nightly.bridge-core.app/
2. Click the Choose Project Button
3. Click Import Project
4. Choose the .BRPROJECT File and it will load in!